// Dashboard JavaScript
(function() {
    'use strict';

    // Protect dashboard
    protectDashboard();

    // Navigation items configuration
    const navItems = [
        { id: 'home', label: 'Home', icon: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
        { id: 'profile', label: 'Child Profile', icon: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>' },
        { id: 'growth', label: 'Growth', icon: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>' },
        { id: 'speech', label: 'Speech', icon: '<path d="M12 2a10 10 0 0 1 10 10v1a3.5 3.5 0 0 1-6.39 1.97M2 12C2 6.48 6.48 2 12 2m0 18a10 10 0 0 1-10-10v-1a3.5 3.5 0 0 1 6.39-1.97M22 12c0 5.52-4.48 10-10 10"/>' },
        { id: 'motor', label: 'Motor Skills', icon: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>' },
        { id: 'activities', label: 'Activities', icon: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>' },
        { id: 'clinic', label: 'Book Clinic', icon: '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>' },
        { id: 'reports', label: 'Reports', icon: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>' }
    ];

    // Initialize navigation
    function initNav() {
        const navContainer = document.getElementById('sidebar-nav');
        if (!navContainer) return;

        navContainer.innerHTML = navItems.map(item => `
            <button class="nav-item ${item.id === 'home' ? 'active' : ''}" data-view="${item.id}">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    ${item.icon}
                </svg>
                <span>${item.label}</span>
            </button>
        `).join('');

        // Add click handlers
        navContainer.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function() {
                const view = this.dataset.view;
                switchView(view);
            });
        });
    }

    // Switch view
    function switchView(viewId) {
        // Update active nav item
        document.querySelectorAll('.nav-item').forEach(item => {
            if (item.dataset.view === viewId) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });

        // Load view content
        loadView(viewId);
    }

    // Load view content
    function loadView(viewId) {
        const contentContainer = document.getElementById('dashboard-content');
        if (!contentContainer) return;

        const views = {
            'home': getHomeView,
            'profile': getProfileView,
            'growth': getGrowthView,
            'speech': getSpeechView,
            'motor': getMotorView,
            'activities': getActivitiesView,
            'clinic': getClinicView,
            'reports': getReportsView,
            'settings': getSettingsView
        };

        const viewFunction = views[viewId] || views['home'];
        contentContainer.innerHTML = viewFunction();
    }

    // View templates
    function getHomeView() {
        const template = document.getElementById('home-view-template');
        return template ? template.innerHTML : '<p>Loading...</p>';
    }

    function getProfileView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Child Profile</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Manage your child's information</p>
                
                <div class="dashboard-card" style="padding: 4rem; text-align: center;">
                    <div class="child-avatar" style="margin: 0 auto 1.5rem;">E</div>
                    <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem;">Emma Johnson</h2>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Born: August 23, 2024 • 15 months old</p>
                    <button class="btn btn-gradient btn-lg">Edit Profile</button>
                </div>
            </div>
        `;
    }

    function getGrowthView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Growth Tracking</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Monitor your child's physical development</p>
                
                <div class="dashboard-card" style="padding: 5rem 2.5rem; text-align: center;">
                    <div style="font-size: 4rem; margin-bottom: 1.5rem;">📊</div>
                    <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem;">Growth Charts & Tracking</h3>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Track height, weight, and head circumference against WHO standards</p>
                    <button class="btn btn-gradient btn-lg">Add Measurement</button>
                </div>
            </div>
        `;
    }

    function getSpeechView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Speech Analysis 🧠</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">AI-powered speech assessment and tracking</p>
                
                <div style="background: linear-gradient(135deg, var(--purple-50), var(--blue-50)); border: 2px solid var(--purple-200); border-radius: var(--radius-xl); padding: 5rem 2.5rem; text-align: center;">
                    <span class="badge" style="background: linear-gradient(135deg, var(--blue-500), var(--purple-500)); color: white; border: none; margin-bottom: 1.5rem;">Premium Feature</span>
                    <div style="font-size: 4rem; margin-bottom: 1.5rem;">🎤</div>
                    <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem;">Speech Development Tracking</h3>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Record and analyze your child's speech patterns with AI-powered insights</p>
                    <button class="btn btn-gradient btn-lg">Start Recording</button>
                </div>
            </div>
        `;
    }

    function getMotorView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Motor Skills Development 🎯</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Track fine and gross motor development</p>
                
                <div style="background: linear-gradient(135deg, var(--green-50), var(--blue-50)); border: 2px solid var(--green-200); border-radius: var(--radius-xl); padding: 5rem 2.5rem; text-align: center;">
                    <span class="badge" style="background: linear-gradient(135deg, var(--blue-500), var(--purple-500)); color: white; border: none; margin-bottom: 1.5rem;">Premium Feature</span>
                    <div style="font-size: 4rem; margin-bottom: 1.5rem;">🤸</div>
                    <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem;">Motor Skills Assessment</h3>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Video-based analysis of fine and gross motor skills development</p>
                    <button class="btn btn-gradient btn-lg">Upload Video</button>
                </div>
            </div>
        `;
    }

    function getActivitiesView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Daily Activities ✨</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Personalized activities for your child's development</p>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;">
                    <div class="dashboard-card">
                        <div class="card-content">
                            <div style="width: 3rem; height: 3rem; background: var(--blue-100); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">📚</div>
                            <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;">Story Time</h3>
                            <p style="color: var(--slate-600); line-height: 1.6; margin-bottom: 1rem;">Interactive reading session with vocabulary building</p>
                            <span class="badge badge-green">Age Appropriate</span>
                        </div>
                    </div>
                    
                    <div class="dashboard-card">
                        <div class="card-content">
                            <div style="width: 3rem; height: 3rem; background: var(--purple-100); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">🎨</div>
                            <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;">Creative Play</h3>
                            <p style="color: var(--slate-600); line-height: 1.6; margin-bottom: 1rem;">Finger painting and sensory exploration activities</p>
                            <span class="badge badge-green">Age Appropriate</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function getClinicView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Book Clinic Appointment 📅</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Schedule visits with pediatricians and specialists</p>
                
                <div style="background: linear-gradient(135deg, var(--blue-50), var(--purple-50)); border: 2px solid var(--blue-200); border-radius: var(--radius-xl); padding: 5rem 2.5rem; text-align: center;">
                    <span class="badge" style="background: linear-gradient(135deg, var(--blue-500), var(--purple-500)); color: white; border: none; margin-bottom: 1.5rem;">Premium Feature</span>
                    <div style="font-size: 4rem; margin-bottom: 1.5rem;">🏥</div>
                    <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem;">Clinic Booking System</h3>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Book appointments with verified pediatricians and specialists</p>
                    <button class="btn btn-gradient btn-lg">Find a Clinic</button>
                </div>
            </div>
        `;
    }

    function getReportsView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Development Reports 📄</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Comprehensive reports for healthcare providers</p>
                
                <div style="background: linear-gradient(135deg, var(--purple-50), var(--pink-50)); border: 2px solid var(--purple-200); border-radius: var(--radius-xl); padding: 5rem 2.5rem; text-align: center;">
                    <span class="badge" style="background: linear-gradient(135deg, var(--blue-500), var(--purple-500)); color: white; border: none; margin-bottom: 1.5rem;">Premium Feature</span>
                    <div style="font-size: 4rem; margin-bottom: 1.5rem;">📊</div>
                    <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.75rem;">Professional Reports</h3>
                    <p style="color: var(--slate-600); margin-bottom: 1.5rem;">Generate detailed development reports to share with healthcare providers</p>
                    <button class="btn btn-gradient btn-lg">Generate Report</button>
                </div>
            </div>
        `;
    }

    function getSettingsView() {
        return `
            <div class="dashboard-content">
                <h1 class="dashboard-title">Settings ⚙️</h1>
                <p class="dashboard-subtitle" style="margin-bottom: 2rem;">Manage your account and preferences</p>
                
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3 class="card-title">Account Settings</h3>
                    </div>
                    <div class="card-content" style="gap: 1.5rem;">
                        <div>
                            <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem;">Profile Information</h4>
                            <p style="color: var(--slate-600);">Update your personal information and preferences</p>
                        </div>
                        <div>
                            <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem;">Notifications</h4>
                            <p style="color: var(--slate-600);">Manage email and push notification settings</p>
                        </div>
                        <div>
                            <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem;">Subscription</h4>
                            <p style="color: var(--slate-600); margin-bottom: 0.75rem;">Current Plan: <strong>Premium</strong></p>
                            <button class="btn btn-outline">Manage Subscription</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Initialize
    initNav();
    loadView('home');
})();

// Handle logout
function handleLogout() {
    if (confirm('Are you sure you want to log out?')) {
        clearAuth();
        navigateTo('index');
    }
}
