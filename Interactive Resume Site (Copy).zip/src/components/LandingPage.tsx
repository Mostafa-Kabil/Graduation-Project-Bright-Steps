import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle2, Brain, TrendingUp, Target, Sparkles, Shield, Heart, Users, Award, Calendar } from 'lucide-react';
import logo from 'figma:asset/e09f16cfad98256171e82a0144b696de7a43fcbe.png';

interface LandingPageProps {
  onLogin: () => void;
  onSignup: () => void;
}

export function LandingPage({ onLogin, onSignup }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Bright Steps" className="h-10" />
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={onLogin}>Log In</Button>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700" onClick={onSignup}>
              Get Started Free
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="bg-purple-100 text-purple-700 border-purple-200 mb-4">
              <Sparkles className="w-3 h-3 mr-1" />
              AI-Powered Development Tracking
            </Badge>
            <h1 className="text-5xl text-slate-900 mb-6">
              Your child's bright future starts here
            </h1>
            <p className="text-xl text-slate-600 mb-8">
              Monitor your child's growth, speech, and development with AI-powered insights. Get personalized recommendations and early alerts to ensure every step is a bright one.
            </p>
            <div className="flex items-center gap-4 mb-8">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8" onClick={onSignup}>
                Start Tracking Free
              </Button>
              <Button size="lg" variant="outline" className="text-lg">
                Watch Demo
              </Button>
            </div>
            <div className="flex items-center gap-6 text-slate-600">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span>Free 7-day trial</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span>No credit card required</span>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="relative bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl p-8 shadow-2xl">
              <div className="bg-white rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full"></div>
                  <div>
                    <div className="h-4 bg-slate-200 rounded w-32 mb-2"></div>
                    <div className="h-3 bg-slate-100 rounded w-24"></div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
                    <div className="w-8 h-8 bg-green-500 rounded-full mx-auto mb-2"></div>
                    <div className="h-2 bg-green-200 rounded w-12 mx-auto"></div>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
                    <div className="w-8 h-8 bg-blue-500 rounded-full mx-auto mb-2"></div>
                    <div className="h-2 bg-blue-200 rounded w-12 mx-auto"></div>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
                    <div className="w-8 h-8 bg-purple-500 rounded-full mx-auto mb-2"></div>
                    <div className="h-2 bg-purple-200 rounded w-12 mx-auto"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="h-3 bg-slate-100 rounded w-full"></div>
                  <div className="h-3 bg-slate-100 rounded w-4/5"></div>
                  <div className="h-3 bg-slate-100 rounded w-3/5"></div>
                </div>
              </div>
            </div>
            <div className="absolute -top-4 -right-4 bg-yellow-400 rounded-2xl p-4 shadow-xl rotate-12">
              <Award className="w-8 h-8 text-yellow-800" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-green-400 rounded-2xl p-4 shadow-xl -rotate-12">
              <Heart className="w-8 h-8 text-green-800" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-slate-900 mb-4">Everything you need in one place</h2>
            <p className="text-xl text-slate-600">Comprehensive AI-powered tools for your child's development</p>
          </div>
          <div className="grid grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-8 border border-blue-200">
              <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Growth Tracking</h3>
              <p className="text-slate-600 mb-4">
                Monitor height, weight, and head circumference against WHO standards with AI-powered analytics and early alerts.
              </p>
              <Badge className="bg-blue-200 text-blue-800 border-blue-300">Always Free</Badge>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-8 border border-purple-200">
              <div className="w-14 h-14 bg-purple-600 rounded-xl flex items-center justify-center mb-4">
                <Brain className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Speech Analysis</h3>
              <p className="text-slate-600 mb-4">
                Upload voice recordings and get AI-driven evaluation of vocabulary, pronunciation, and grammar development.
              </p>
              <Badge className="bg-purple-200 text-purple-800 border-purple-300">Premium</Badge>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 border border-green-200">
              <div className="w-14 h-14 bg-green-600 rounded-xl flex items-center justify-center mb-4">
                <Target className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Motor Skills</h3>
              <p className="text-slate-600 mb-4">
                AI analyzes activity videos to detect motor delays and provides personalized exercises for improvement.
              </p>
              <Badge className="bg-green-200 text-green-800 border-green-300">Premium</Badge>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-8 border border-orange-200">
              <div className="w-14 h-14 bg-orange-600 rounded-xl flex items-center justify-center mb-4">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Smart Recommendations</h3>
              <p className="text-slate-600 mb-4">
                Get personalized daily and weekly activities, exercises, and milestone checklists tailored to your child's age.
              </p>
              <Badge className="bg-orange-200 text-orange-800 border-orange-300">Premium</Badge>
            </div>

            <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-2xl p-8 border border-pink-200">
              <div className="w-14 h-14 bg-pink-600 rounded-xl flex items-center justify-center mb-4">
                <Calendar className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Clinic Booking</h3>
              <p className="text-slate-600 mb-4">
                Book appointments with pediatricians and therapists directly. Share progress reports with healthcare providers.
              </p>
              <Badge className="bg-pink-200 text-pink-800 border-pink-300">Premium</Badge>
            </div>

            <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-2xl p-8 border border-cyan-200">
              <div className="w-14 h-14 bg-cyan-600 rounded-xl flex items-center justify-center mb-4">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-slate-900 mb-3">Secure & Private</h3>
              <p className="text-slate-600 mb-4">
                Your child's data is encrypted and securely stored. You have complete control over data sharing.
              </p>
              <Badge className="bg-cyan-200 text-cyan-800 border-cyan-300">All Plans</Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Traffic Light System */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-slate-900 mb-4">Simple, clear insights you can trust</h2>
            <p className="text-xl text-slate-600">Our traffic-light system makes understanding development easy</p>
          </div>
          <div className="grid grid-cols-3 gap-8">
            <div className="bg-white border-2 border-green-200 rounded-2xl p-8 text-center">
              <div className="w-20 h-20 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                <CheckCircle2 className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-slate-900 mb-2">Green - On Track</h3>
              <p className="text-slate-600">
                Your child is meeting age-appropriate milestones. Keep up the great work!
              </p>
            </div>

            <div className="bg-white border-2 border-yellow-200 rounded-2xl p-8 text-center">
              <div className="w-20 h-20 bg-yellow-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                <Target className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-slate-900 mb-2">Yellow - Needs Attention</h3>
              <p className="text-slate-600">
                Some areas need monitoring. We'll provide exercises and activities to help.
              </p>
            </div>

            <div className="bg-white border-2 border-red-200 rounded-2xl p-8 text-center">
              <div className="w-20 h-20 bg-red-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-slate-900 mb-2">Red - Seek Help</h3>
              <p className="text-slate-600">
                We recommend consulting a healthcare professional. We'll help you book an appointment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="bg-slate-50 py-20 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-slate-900 mb-4">Simple, transparent pricing</h2>
            <p className="text-xl text-slate-600">Start free, upgrade when you're ready</p>
          </div>
          <div className="grid grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl p-8 border-2 border-slate-200">
              <h3 className="text-2xl text-slate-900 mb-2">Free Forever</h3>
              <p className="text-slate-600 mb-6">Essential tracking for every parent</p>
              <div className="text-4xl text-slate-900 mb-6">$0</div>
              <Button variant="outline" size="lg" className="w-full mb-6" onClick={onSignup}>
                Get Started Free
              </Button>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Growth tracking & WHO comparisons</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Basic milestone checklists</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Traffic-light alerts</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                  <span className="text-slate-700">Gamification & badges</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-8 border-2 border-blue-600 relative">
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-yellow-400 text-yellow-900 border-yellow-500">
                Most Popular
              </Badge>
              <h3 className="text-2xl text-white mb-2">Premium</h3>
              <p className="text-blue-100 mb-6">Complete AI-powered monitoring</p>
              <div className="text-4xl text-white mb-6">
                $9.99<span className="text-xl text-blue-100">/month</span>
              </div>
              <Button size="lg" className="w-full mb-6 bg-white text-blue-600 hover:bg-blue-50" onClick={onSignup}>
                Start 7-Day Free Trial
              </Button>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">Everything in Free, plus:</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">AI speech & language analysis</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">Motor skills video assessment</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">Personalized recommendations</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">Doctor-ready PDF reports</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-100 mt-0.5" />
                  <span className="text-white">Clinic booking integration</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl text-slate-900 mb-6">
            Start your child's bright journey today
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            Join thousands of parents who trust Bright Steps for their child's development
          </p>
          <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-12" onClick={onSignup}>
            Get Started Free - No Credit Card Required
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-4 gap-8 mb-8">
            <div>
              <img src={logo} alt="Bright Steps" className="h-10 mb-4 brightness-0 invert" />
              <p className="text-slate-400">
                AI-powered child development monitoring for ages 0-5
              </p>
            </div>
            <div>
              <h4 className="text-white mb-4">Product</h4>
              <ul className="space-y-2 text-slate-400">
                <li>Features</li>
                <li>Pricing</li>
                <li>Premium</li>
                <li>Mobile App</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white mb-4">Resources</h4>
              <ul className="space-y-2 text-slate-400">
                <li>Help Center</li>
                <li>Guidelines</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white mb-4">Company</h4>
              <ul className="space-y-2 text-slate-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>For Clinics</li>
                <li>Careers</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-slate-400">
            © 2025 Bright Steps. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
