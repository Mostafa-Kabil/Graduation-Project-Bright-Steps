import { User, Bell, Shield, CreditCard, Crown, LogOut, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Switch } from '../ui/switch';
import { Label } from '../ui/label';
import { Avatar, AvatarFallback } from '../ui/avatar';

export function SettingsPage() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">Settings</h1>
        <p className="text-slate-600">Manage your account and preferences</p>
      </div>

      {/* Account Info */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <Avatar className="w-20 h-20 border-4 border-white shadow-lg">
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-2xl">
                SJ
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl text-slate-900 mb-1">Sarah Johnson</h2>
              <p className="text-slate-600 mb-2">sarah.johnson@email.com</p>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0">
                <Crown className="w-3 h-3 mr-1" />
                Premium Member
              </Badge>
            </div>
            <Button variant="outline">
              Edit Profile
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Subscription */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Subscription & Billing
            </CardTitle>
            <Badge className="bg-green-100 text-green-700 border-green-200">
              Active
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-200">
            <div>
              <div className="text-lg text-slate-900 mb-1">Premium Plan</div>
              <div className="text-slate-600">$9.99/month • Renews Dec 1, 2025</div>
            </div>
            <div className="text-right">
              <div className="text-2xl text-slate-900 mb-1">$9.99</div>
              <div className="text-sm text-slate-600">per month</div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">
              Change Plan
            </Button>
            <Button variant="outline" className="flex-1">
              Billing History
            </Button>
            <Button variant="outline" className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50">
              Cancel Subscription
            </Button>
          </div>

          <div className="bg-slate-50 rounded-lg p-4">
            <h4 className="text-slate-900 mb-2">Premium Benefits</h4>
            <ul className="space-y-1 text-sm text-slate-600">
              <li>• AI-powered speech & language analysis</li>
              <li>• Motor skills video assessment</li>
              <li>• Unlimited personalized recommendations</li>
              <li>• Professional PDF reports</li>
              <li>• Direct clinic booking integration</li>
              <li>• Priority customer support</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <Label htmlFor="daily-reminders" className="cursor-pointer">
                Daily Activity Reminders
              </Label>
              <p className="text-sm text-slate-500">Get notified about today's recommended activities</p>
            </div>
            <Switch id="daily-reminders" defaultChecked />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <Label htmlFor="milestone-alerts" className="cursor-pointer">
                Milestone Alerts
              </Label>
              <p className="text-sm text-slate-500">Notifications when milestones are approaching</p>
            </div>
            <Switch id="milestone-alerts" defaultChecked />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <Label htmlFor="appointment-reminders" className="cursor-pointer">
                Appointment Reminders
              </Label>
              <p className="text-sm text-slate-500">Reminders for upcoming doctor visits</p>
            </div>
            <Switch id="appointment-reminders" defaultChecked />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <Label htmlFor="growth-updates" className="cursor-pointer">
                Growth Tracking Updates
              </Label>
              <p className="text-sm text-slate-500">Weekly reminders to log growth measurements</p>
            </div>
            <Switch id="growth-updates" defaultChecked />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div>
              <Label htmlFor="email-notifications" className="cursor-pointer">
                Email Notifications
              </Label>
              <p className="text-sm text-slate-500">Receive updates via email</p>
            </div>
            <Switch id="email-notifications" />
          </div>
        </CardContent>
      </Card>

      {/* Privacy & Security */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Privacy & Security
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900 mb-1">Change Password</div>
              <div className="text-sm text-slate-500">Update your account password</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900 mb-1">Data Privacy Settings</div>
              <div className="text-sm text-slate-500">Manage how your data is used and stored</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900 mb-1">Download My Data</div>
              <div className="text-sm text-slate-500">Export all your child's data</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-red-50 rounded-lg hover:bg-red-100 transition-colors border border-red-200">
            <div className="text-left">
              <div className="text-red-700 mb-1">Delete Account</div>
              <div className="text-sm text-red-600">Permanently delete your account and all data</div>
            </div>
            <ChevronRight className="w-5 h-5 text-red-400" />
          </button>
        </CardContent>
      </Card>

      {/* Help & Support */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Help & Support</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900">Help Center</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900">Contact Support</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900">Terms of Service</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <div className="text-left">
              <div className="text-slate-900">Privacy Policy</div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card className="border-slate-200">
        <CardContent className="p-6 text-center">
          <div className="text-sm text-slate-600 mb-2">Bright Steps</div>
          <div className="text-xs text-slate-500">Version 1.0.0</div>
          <div className="text-xs text-slate-500 mt-4">© 2025 Bright Steps. All rights reserved.</div>
        </CardContent>
      </Card>
    </div>
  );
}
