import { Camera, Plus, Edit2, Save } from 'lucide-react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';

export function ChildProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: 'Emma',
    lastName: 'Johnson',
    dateOfBirth: '2024-08-23',
    gender: 'Female',
    bloodType: 'O+',
    allergies: 'None',
    medicalConditions: 'None',
    pediatrician: 'Dr. Sarah Smith',
    emergencyContact: '+1 (555) 123-4567',
    notes: 'Loves picture books and outdoor activities. Prefers quiet environments.',
  });

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Child Profile</h1>
          <p className="text-slate-600">Manage your child's information</p>
        </div>
        {!isEditing ? (
          <Button onClick={() => setIsEditing(true)} className="bg-blue-600 hover:bg-blue-700">
            <Edit2 className="w-4 h-4 mr-2" />
            Edit Profile
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setIsEditing(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsEditing(false)} className="bg-green-600 hover:bg-green-700">
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        )}
      </div>

      {/* Profile Card */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-8">
          <div className="flex items-start gap-8">
            <div className="relative">
              <Avatar className="w-32 h-32 border-4 border-white shadow-xl">
                <AvatarFallback className="text-4xl bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                  E
                </AvatarFallback>
              </Avatar>
              {isEditing && (
                <button className="absolute bottom-0 right-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors">
                  <Camera className="w-5 h-5 text-white" />
                </button>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-3xl text-slate-900 mb-2">
                    {formData.firstName} {formData.lastName}
                  </h2>
                  <div className="flex items-center gap-3 text-slate-600">
                    <span>15 months old</span>
                    <span>•</span>
                    <span>Born: August 23, 2024</span>
                    <span>•</span>
                    <Badge variant="outline" className="bg-pink-100 text-pink-700 border-pink-200">
                      {formData.gender}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white rounded-xl p-4 border border-slate-200">
                  <div className="text-xs text-slate-500 mb-1">Blood Type</div>
                  <div className="text-slate-900">{formData.bloodType}</div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-slate-200">
                  <div className="text-xs text-slate-500 mb-1">Current Weight</div>
                  <div className="text-slate-900">11.1 kg</div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-slate-200">
                  <div className="text-xs text-slate-500 mb-1">Current Height</div>
                  <div className="text-slate-900">78 cm</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Basic Information */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <Label>First Name</Label>
              <Input
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Last Name</Label>
              <Input
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Date of Birth</Label>
              <Input
                type="date"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Gender</Label>
              <Input
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Blood Type</Label>
              <Input
                value={formData.bloodType}
                onChange={(e) => setFormData({ ...formData, bloodType: e.target.value })}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Medical Information */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Medical Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Allergies</Label>
            <Input
              value={formData.allergies}
              onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
              disabled={!isEditing}
              className="mt-1"
              placeholder="List any known allergies"
            />
          </div>
          <div>
            <Label>Medical Conditions</Label>
            <Input
              value={formData.medicalConditions}
              onChange={(e) => setFormData({ ...formData, medicalConditions: e.target.value })}
              disabled={!isEditing}
              className="mt-1"
              placeholder="List any medical conditions"
            />
          </div>
          <div>
            <Label>Primary Pediatrician</Label>
            <Input
              value={formData.pediatrician}
              onChange={(e) => setFormData({ ...formData, pediatrician: e.target.value })}
              disabled={!isEditing}
              className="mt-1"
            />
          </div>
          <div>
            <Label>Emergency Contact</Label>
            <Input
              value={formData.emergencyContact}
              onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
              disabled={!isEditing}
              className="mt-1"
            />
          </div>
        </CardContent>
      </Card>

      {/* Additional Notes */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Additional Notes</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            disabled={!isEditing}
            rows={4}
            placeholder="Add any additional notes about your child..."
          />
        </CardContent>
      </Card>

      {/* Multiple Children Support */}
      <Card className="border-2 border-dashed border-slate-300 bg-slate-50">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-slate-900 mb-2">Add Another Child</h3>
          <p className="text-slate-600 mb-4">Track development for multiple children in one account</p>
          <Button variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Child Profile
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
