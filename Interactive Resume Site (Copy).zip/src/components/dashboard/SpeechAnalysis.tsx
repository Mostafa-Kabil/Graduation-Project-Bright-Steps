import { Mic, Upload, Play, CheckCircle2, AlertCircle, Sparkles, Crown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

const analysisHistory = [
  {
    id: 1,
    date: 'Nov 20, 2025',
    duration: '45 sec',
    vocabulary: 12,
    clarity: 75,
    grammar: 60,
    status: 'yellow',
    insights: 'Good progress! Vocabulary is expanding. Work on pronunciation clarity.',
  },
  {
    id: 2,
    date: 'Nov 15, 2025',
    duration: '38 sec',
    vocabulary: 10,
    clarity: 70,
    grammar: 55,
    status: 'yellow',
    insights: 'Steady improvement in word count. Continue daily reading activities.',
  },
  {
    id: 3,
    date: 'Nov 10, 2025',
    duration: '42 sec',
    vocabulary: 9,
    clarity: 68,
    grammar: 50,
    status: 'yellow',
    insights: 'Making progress with new words. Encourage more storytelling.',
  },
];

export function SpeechAnalysis() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Speech & Language Analysis</h1>
          <p className="text-slate-600">AI-powered evaluation of vocabulary, pronunciation, and grammar</p>
        </div>
        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 px-4 py-2">
          <Crown className="w-4 h-4 mr-2" />
          Premium Feature
        </Badge>
      </div>

      {/* Upload Section */}
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl text-slate-900 mb-2">Record New Speech Sample</h2>
            <p className="text-slate-600 mb-6">
              Record 30-60 seconds of your child speaking naturally. AI will analyze vocabulary, pronunciation, and grammar.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                <Mic className="w-5 h-5 mr-2" />
                Start Recording
              </Button>
              <Button size="lg" variant="outline">
                <Upload className="w-5 h-5 mr-2" />
                Upload Audio File
              </Button>
            </div>
            <p className="text-sm text-slate-500 mt-4">
              Supported formats: MP3, WAV, M4A (Max 2 minutes)
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Current Status */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Vocabulary Size</div>
              <Badge className="bg-yellow-500 text-white">
                Age 15m
              </Badge>
            </div>
            <div className="text-4xl text-slate-900 mb-2">12 words</div>
            <div className="text-sm text-slate-600 mb-3">Expected: 10-15 words</div>
            <Progress value={80} className="h-2 mb-2" />
            <div className="text-xs text-yellow-700">On track for age group</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Clarity Score</div>
              <Badge className="bg-orange-500 text-white">
                Latest
              </Badge>
            </div>
            <div className="text-4xl text-slate-900 mb-2">75%</div>
            <div className="text-sm text-slate-600 mb-3">Pronunciation clarity</div>
            <Progress value={75} className="h-2 mb-2" />
            <div className="text-xs text-orange-700">Improving steadily</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-pink-200 bg-gradient-to-br from-pink-50 to-pink-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Grammar Development</div>
              <Badge className="bg-pink-500 text-white">
                Early Stage
              </Badge>
            </div>
            <div className="text-4xl text-slate-900 mb-2">60%</div>
            <div className="text-sm text-slate-600 mb-3">Word combination skills</div>
            <Progress value={60} className="h-2 mb-2" />
            <div className="text-xs text-pink-700">Normal for age</div>
          </CardContent>
        </Card>
      </div>

      {/* Overall Assessment */}
      <Card className="border-2 border-yellow-200 bg-gradient-to-r from-yellow-50 to-yellow-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-slate-900 mb-1">Speech Status: Needs Attention</h3>
              <p className="text-slate-600">
                Emma is making good progress but could benefit from more daily language practice. Continue with reading activities and encourage verbal communication throughout the day.
              </p>
            </div>
            <Badge className="bg-yellow-500 text-white text-lg px-4 py-2">
              Yellow - Monitor
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* AI Recommendations */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            AI-Powered Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-4 p-4 bg-purple-50 border border-purple-200 rounded-xl">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Daily Reading Time</h4>
              <p className="text-sm text-slate-600">
                Read picture books together for 15-20 minutes daily. Point to objects and clearly pronounce their names. This helps build vocabulary and improves clarity.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Narrate Daily Activities</h4>
              <p className="text-sm text-slate-600">
                Describe what you're doing throughout the day. "We're putting on your shoes." "Let's eat breakfast." This natural language exposure is crucial at this age.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-green-50 border border-green-200 rounded-xl">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Simple Songs & Rhymes</h4>
              <p className="text-sm text-slate-600">
                Sing nursery rhymes and simple songs. The repetition and rhythm help with pronunciation and memory. Encourage Emma to join in with sounds and words.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-orange-50 border border-orange-200 rounded-xl">
            <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Respond to Attempts</h4>
              <p className="text-sm text-slate-600">
                When Emma tries to communicate, respond positively even if words aren't clear. Repeat back correctly without criticism: "Yes, that's a dog!"
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analysis History */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Recent Speech Analyses</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {analysisHistory.map((analysis) => (
            <div
              key={analysis.id}
              className="p-4 border-2 border-slate-200 rounded-xl hover:border-purple-300 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="text-slate-900 mb-1">{analysis.date}</div>
                  <div className="text-sm text-slate-500">Duration: {analysis.duration}</div>
                </div>
                <Button variant="ghost" size="sm">
                  <Play className="w-4 h-4 mr-2" />
                  Play
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-3">
                <div>
                  <div className="text-xs text-slate-500 mb-1">Vocabulary</div>
                  <div className="text-lg text-slate-900">{analysis.vocabulary} words</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1">Clarity</div>
                  <div className="text-lg text-slate-900">{analysis.clarity}%</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1">Grammar</div>
                  <div className="text-lg text-slate-900">{analysis.grammar}%</div>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-3">
                <div className="text-sm text-slate-700">{analysis.insights}</div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Educational Resources */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50">
        <CardContent className="p-6">
          <h3 className="text-slate-900 mb-3">Need Professional Help?</h3>
          <p className="text-slate-600 mb-4">
            If you're concerned about Emma's speech development, consider consulting a speech-language pathologist. We can help you find specialists in your area.
          </p>
          <Button variant="outline">
            Find Speech Therapist
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
