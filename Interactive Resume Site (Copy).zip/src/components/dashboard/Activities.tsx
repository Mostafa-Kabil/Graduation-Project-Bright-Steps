import { Sparkles, CheckCircle2, Clock, Trophy, Calendar, Plus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

const todayActivities = [
  {
    id: 1,
    title: 'Morning Reading',
    category: 'language',
    duration: '15 min',
    completed: true,
    description: 'Read picture books and name objects',
    points: 10,
  },
  {
    id: 2,
    title: 'Block Stacking',
    category: 'motor',
    duration: '10 min',
    completed: true,
    description: 'Build towers with colorful blocks',
    points: 10,
  },
  {
    id: 3,
    title: 'Outdoor Walk',
    category: 'motor',
    duration: '20 min',
    completed: false,
    description: 'Practice walking on different surfaces',
    points: 15,
  },
  {
    id: 4,
    title: 'Singing Songs',
    category: 'language',
    duration: '10 min',
    completed: false,
    description: 'Sing nursery rhymes together',
    points: 10,
  },
  {
    id: 5,
    title: 'Puzzle Time',
    category: 'cognitive',
    duration: '15 min',
    completed: false,
    description: 'Simple shape sorting puzzle',
    points: 10,
  },
];

const weeklyGoal = {
  current: 6,
  target: 7,
  streak: 14,
};

const activityLibrary = [
  {
    category: 'Language Development',
    color: 'purple',
    activities: [
      { title: 'Picture Book Reading', age: '12-24m', duration: '15 min' },
      { title: 'Name the Object Game', age: '15-24m', duration: '10 min' },
      { title: 'Animal Sounds Practice', age: '12-18m', duration: '10 min' },
      { title: 'Simple Storytelling', age: '18-24m', duration: '15 min' },
    ],
  },
  {
    category: 'Motor Skills',
    color: 'green',
    activities: [
      { title: 'Ball Rolling & Kicking', age: '15-24m', duration: '15 min' },
      { title: 'Stacking Blocks Tower', age: '12-18m', duration: '10 min' },
      { title: 'Outdoor Walking Practice', age: '12-24m', duration: '20 min' },
      { title: 'Climbing Soft Stairs', age: '15-24m', duration: '10 min' },
    ],
  },
  {
    category: 'Cognitive Development',
    color: 'blue',
    activities: [
      { title: 'Shape Sorting', age: '15-24m', duration: '15 min' },
      { title: 'Hide and Seek Objects', age: '12-18m', duration: '10 min' },
      { title: 'Color Recognition', age: '18-24m', duration: '10 min' },
      { title: 'Simple Puzzle Solving', age: '15-24m', duration: '15 min' },
    ],
  },
  {
    category: 'Social & Emotional',
    color: 'pink',
    activities: [
      { title: 'Peek-a-Boo Games', age: '12-18m', duration: '10 min' },
      { title: 'Sharing Toys Practice', age: '15-24m', duration: '15 min' },
      { title: 'Mirroring Emotions', age: '12-24m', duration: '10 min' },
      { title: 'Parent-Child Play', age: '12-24m', duration: '20 min' },
    ],
  },
];

export function Activities() {
  const completedToday = todayActivities.filter(a => a.completed).length;
  const totalPoints = todayActivities.filter(a => a.completed).reduce((sum, a) => sum + a.points, 0);

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Daily Activities</h1>
          <p className="text-slate-600">Personalized recommendations for Emma's development</p>
        </div>
        <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Create Custom Activity
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6">
        <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-slate-600 text-sm">Daily Streak</div>
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                <Trophy className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl text-slate-900 mb-1">{weeklyGoal.streak} days</div>
            <div className="text-xs text-orange-700">Keep it going! 🔥</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-slate-600 text-sm">Today's Progress</div>
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl text-slate-900 mb-1">{completedToday}/{todayActivities.length}</div>
            <div className="text-xs text-blue-700">Activities completed</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-slate-600 text-sm">Points Earned</div>
              <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl text-slate-900 mb-1">{totalPoints} pts</div>
            <div className="text-xs text-purple-700">This week: 285 pts</div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-slate-600 text-sm">Weekly Goal</div>
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="text-3xl text-slate-900 mb-1">{weeklyGoal.current}/{weeklyGoal.target}</div>
            <div className="text-xs text-green-700">Days this week</div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Activities */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Today's Recommended Activities</CardTitle>
            <div className="text-sm text-slate-600">
              {completedToday}/{todayActivities.length} completed
            </div>
          </div>
          <Progress value={(completedToday / todayActivities.length) * 100} className="h-2 mt-2" />
        </CardHeader>
        <CardContent className="space-y-3">
          {todayActivities.map((activity) => (
            <div
              key={activity.id}
              className={`flex items-start gap-4 p-4 rounded-xl border-2 transition-all ${
                activity.completed
                  ? 'bg-green-50 border-green-200 opacity-75'
                  : 'bg-white border-slate-200 hover:border-blue-300'
              }`}
            >
              <div className="pt-1">
                {activity.completed ? (
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </div>
                ) : (
                  <div className="w-6 h-6 bg-slate-200 rounded-full"></div>
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className={`mb-1 ${activity.completed ? 'text-slate-700 line-through' : 'text-slate-900'}`}>
                      {activity.title}
                    </h4>
                    <p className="text-sm text-slate-600">{activity.description}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      activity.category === 'language'
                        ? 'bg-purple-100 text-purple-700 border-purple-200'
                        : activity.category === 'motor'
                        ? 'bg-green-100 text-green-700 border-green-200'
                        : 'bg-blue-100 text-blue-700 border-blue-200'
                    }
                  >
                    {activity.category}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{activity.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Sparkles className="w-4 h-4" />
                    <span>{activity.points} points</span>
                  </div>
                </div>
              </div>
              {!activity.completed && (
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  Mark Complete
                </Button>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Activity Library */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Activity Library</CardTitle>
          <p className="text-sm text-slate-600 mt-1">
            Browse age-appropriate activities to add to your daily routine
          </p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="language">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="language">Language</TabsTrigger>
              <TabsTrigger value="motor">Motor</TabsTrigger>
              <TabsTrigger value="cognitive">Cognitive</TabsTrigger>
              <TabsTrigger value="social">Social</TabsTrigger>
            </TabsList>

            {activityLibrary.map((section, idx) => (
              <TabsContent key={idx} value={section.category.toLowerCase().split(' ')[0]}>
                <div className="grid grid-cols-2 gap-4">
                  {section.activities.map((activity, index) => (
                    <div
                      key={index}
                      className={`p-4 border-2 border-${section.color}-200 bg-${section.color}-50 rounded-xl hover:shadow-md transition-all cursor-pointer`}
                    >
                      <h4 className="text-slate-900 mb-2">{activity.title}</h4>
                      <div className="flex items-center gap-3 text-sm text-slate-600 mb-3">
                        <Badge variant="outline" className="text-xs">
                          {activity.age}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{activity.duration}</span>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="w-full">
                        <Plus className="w-3 h-3 mr-2" />
                        Add to Today
                      </Button>
                    </div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card className="border-2 border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50">
        <CardContent className="p-6">
          <h3 className="text-slate-900 mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-600" />
            Recent Achievements
          </h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white rounded-xl border border-yellow-200">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-2 text-2xl">
                🔥
              </div>
              <div className="text-sm text-slate-900 mb-1">2 Week Streak</div>
              <div className="text-xs text-slate-500">Unlocked Nov 20</div>
            </div>
            <div className="text-center p-4 bg-white rounded-xl border border-blue-200">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-2 text-2xl">
                📚
              </div>
              <div className="text-sm text-slate-900 mb-1">Book Lover</div>
              <div className="text-xs text-slate-500">50 reading sessions</div>
            </div>
            <div className="text-center p-4 bg-white rounded-xl border border-green-200">
              <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-2 text-2xl">
                🏃
              </div>
              <div className="text-sm text-slate-900 mb-1">Active Explorer</div>
              <div className="text-xs text-slate-500">100 outdoor activities</div>
            </div>
            <div className="text-center p-4 bg-white rounded-xl border border-purple-200">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-2 text-2xl">
                ⭐
              </div>
              <div className="text-sm text-slate-900 mb-1">Super Parent</div>
              <div className="text-xs text-slate-500">1000 points earned</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
