import { MapPin, Star, Calendar, Clock, Phone, Crown, Search, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';

const upcomingAppointments = [
  {
    id: 1,
    type: 'Vaccination',
    clinic: 'City Pediatric Center',
    doctor: 'Dr. Sarah Smith',
    date: 'Nov 28, 2025',
    time: '10:00 AM',
    status: 'confirmed',
  },
  {
    id: 2,
    type: '15-Month Checkup',
    clinic: 'Children Health Center',
    doctor: 'Dr. Michael Johnson',
    date: 'Dec 15, 2025',
    time: '2:30 PM',
    status: 'confirmed',
  },
];

const clinics = [
  {
    id: 1,
    name: 'City Pediatric Center',
    specialty: 'General Pediatrics',
    rating: 4.8,
    reviews: 324,
    distance: '1.2 km',
    address: '123 Main Street, Downtown',
    image: 'SP',
    available: 'Today',
    doctors: [
      { name: 'Dr. Sarah Smith', specialty: 'Pediatrician' },
      { name: 'Dr. James Wilson', specialty: 'Pediatrician' },
    ],
  },
  {
    id: 2,
    name: 'Children Speech Therapy',
    specialty: 'Speech & Language',
    rating: 4.9,
    reviews: 187,
    distance: '2.5 km',
    address: '456 Oak Avenue, Midtown',
    image: 'ST',
    available: 'Tomorrow',
    doctors: [
      { name: 'Dr. Emily Chen', specialty: 'Speech Therapist' },
    ],
  },
  {
    id: 3,
    name: 'Happy Kids Clinic',
    specialty: 'General Pediatrics',
    rating: 4.7,
    reviews: 452,
    distance: '3.1 km',
    address: '789 Park Road, Westside',
    image: 'HK',
    available: 'This Week',
    doctors: [
      { name: 'Dr. Robert Martinez', specialty: 'Pediatrician' },
      { name: 'Dr. Lisa Anderson', specialty: 'Pediatrician' },
    ],
  },
  {
    id: 4,
    name: 'Developmental Therapy Center',
    specialty: 'Motor Skills & Development',
    rating: 5.0,
    reviews: 95,
    distance: '4.0 km',
    address: '321 Elm Street, Eastside',
    image: 'DT',
    available: 'Next Week',
    doctors: [
      { name: 'Dr. Amanda White', specialty: 'Developmental Therapist' },
    ],
  },
];

export function ClinicBooking() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Clinic Booking</h1>
          <p className="text-slate-600">Find and book appointments with healthcare professionals</p>
        </div>
        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 px-4 py-2">
          <Crown className="w-4 h-4 mr-2" />
          Premium Feature
        </Badge>
      </div>

      {/* Search and Filters */}
      <Card className="border-slate-200">
        <CardContent className="p-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                placeholder="Search by clinic name, specialty, or doctor..."
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Filters
            </Button>
            <Button variant="outline" className="gap-2">
              <MapPin className="w-4 h-4" />
              Near Me
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Upcoming Appointments
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingAppointments.map((appointment) => (
              <div
                key={appointment.id}
                className="flex items-center gap-4 p-4 bg-white border border-blue-200 rounded-xl"
              >
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-slate-900 mb-1">{appointment.type}</div>
                  <div className="text-sm text-slate-600">{appointment.clinic}</div>
                  <div className="text-sm text-slate-600">{appointment.doctor}</div>
                </div>
                <div className="text-right">
                  <div className="text-slate-900 mb-1">{appointment.date}</div>
                  <div className="text-sm text-slate-600">{appointment.time}</div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    Reschedule
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                    Cancel
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Clinics List */}
      <div>
        <h2 className="text-xl text-slate-900 mb-4">Available Clinics & Specialists</h2>
        <div className="space-y-4">
          {clinics.map((clinic) => (
            <Card key={clinic.id} className="border-slate-200 hover:border-blue-300 transition-colors">
              <CardContent className="p-6">
                <div className="flex gap-6">
                  <Avatar className="w-24 h-24 rounded-xl border-2 border-slate-200">
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-xl rounded-xl">
                      {clinic.image}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl text-slate-900 mb-1">{clinic.name}</h3>
                        <p className="text-slate-600 mb-2">{clinic.specialty}</p>
                        <div className="flex items-center gap-4 text-sm text-slate-600">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            <span>{clinic.distance} away</span>
                          </div>
                          <span>{clinic.address}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {clinic.available}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-slate-900">{clinic.rating}</span>
                        <span className="text-slate-500">({clinic.reviews} reviews)</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      {clinic.doctors.map((doctor, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {doctor.name} - {doctor.specialty}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2">
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <Calendar className="w-4 h-4 mr-2" />
                        Book Appointment
                      </Button>
                      <Button variant="outline">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Clinic
                      </Button>
                      <Button variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Specialty Categories */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Browse by Specialty</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            <button className="p-4 border-2 border-blue-200 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🏥</span>
              </div>
              <div className="text-slate-900 mb-1">Pediatricians</div>
              <div className="text-xs text-slate-600">General care</div>
            </button>

            <button className="p-4 border-2 border-purple-200 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors">
              <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">💬</span>
              </div>
              <div className="text-slate-900 mb-1">Speech Therapy</div>
              <div className="text-xs text-slate-600">Language development</div>
            </button>

            <button className="p-4 border-2 border-green-200 bg-green-50 rounded-xl hover:bg-green-100 transition-colors">
              <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🏃</span>
              </div>
              <div className="text-slate-900 mb-1">Physical Therapy</div>
              <div className="text-xs text-slate-600">Motor skills</div>
            </button>

            <button className="p-4 border-2 border-orange-200 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors">
              <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                <span className="text-2xl">🧠</span>
              </div>
              <div className="text-slate-900 mb-1">Developmental</div>
              <div className="text-xs text-slate-600">Cognitive assessment</div>
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Share Reports Feature */}
      <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-slate-900 mb-1">Share Progress Reports</h3>
              <p className="text-slate-600">
                When booking an appointment, you can optionally share Emma's growth charts, speech analysis, and milestone progress with the healthcare provider.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
