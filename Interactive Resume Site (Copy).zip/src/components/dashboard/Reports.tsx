import { FileText, Download, Share2, Crown, Calendar, TrendingUp, Brain, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

const reports = [
  {
    id: 1,
    title: 'Comprehensive Development Report - November 2025',
    date: 'Nov 20, 2025',
    type: 'Monthly Summary',
    status: 'ready',
    includes: ['Growth Charts', 'Speech Analysis', 'Motor Skills', 'Milestones'],
  },
  {
    id: 2,
    title: 'Speech & Language Assessment',
    date: 'Nov 18, 2025',
    type: 'Specialist Report',
    status: 'ready',
    includes: ['Vocabulary Analysis', 'Pronunciation Clarity', 'AI Recommendations'],
  },
  {
    id: 3,
    title: 'Growth Tracking Report - October 2025',
    date: 'Oct 31, 2025',
    type: 'Monthly Summary',
    status: 'ready',
    includes: ['WHO Percentile Charts', 'Weight/Height Trends'],
  },
];

export function Reports() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Reports & Insights</h1>
          <p className="text-slate-600">Generate and download comprehensive development reports</p>
        </div>
        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 px-4 py-2">
          <Crown className="w-4 h-4 mr-2" />
          Premium Feature
        </Badge>
      </div>

      {/* Generate New Report */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl text-slate-900 mb-2">Generate New Report</h2>
            <p className="text-slate-600 mb-6">
              Create a comprehensive PDF report including growth charts, speech analysis, motor skills assessment, and milestone tracking for pediatrician visits.
            </p>
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <FileText className="w-5 h-5 mr-2" />
              Generate Full Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Options */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="border-2 border-green-200 hover:border-green-400 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="text-slate-900 mb-1">Growth Report</h3>
            <p className="text-sm text-slate-600 mb-3">WHO charts & trends</p>
            <Button variant="outline" size="sm" className="w-full">
              Generate
            </Button>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 hover:border-purple-400 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Brain className="w-7 h-7 text-purple-600" />
            </div>
            <h3 className="text-slate-900 mb-1">Speech Report</h3>
            <p className="text-sm text-slate-600 mb-3">Language analysis</p>
            <Button variant="outline" size="sm" className="w-full">
              Generate
            </Button>
          </CardContent>
        </Card>

        <Card className="border-2 border-orange-200 hover:border-orange-400 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Target className="w-7 h-7 text-orange-600" />
            </div>
            <h3 className="text-slate-900 mb-1">Motor Skills Report</h3>
            <p className="text-sm text-slate-600 mb-3">Physical development</p>
            <Button variant="outline" size="sm" className="w-full">
              Generate
            </Button>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 hover:border-blue-400 transition-colors cursor-pointer">
          <CardContent className="p-6 text-center">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Calendar className="w-7 h-7 text-blue-600" />
            </div>
            <h3 className="text-slate-900 mb-1">Milestone Report</h3>
            <p className="text-sm text-slate-600 mb-3">Progress tracking</p>
            <Button variant="outline" size="sm" className="w-full">
              Generate
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Reports */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {reports.map((report) => (
            <div
              key={report.id}
              className="flex items-start gap-4 p-4 border-2 border-slate-200 rounded-xl hover:border-blue-300 transition-colors"
            >
              <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileText className="w-7 h-7 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-slate-900 mb-1">{report.title}</h3>
                    <div className="flex items-center gap-3 text-sm text-slate-600">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{report.date}</span>
                      </div>
                      <Badge variant="outline">{report.type}</Badge>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-700 border-green-200">
                    {report.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  {report.includes.map((item, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs bg-slate-50">
                      {item}
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                  <Button size="sm" variant="outline">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share with Doctor
                  </Button>
                  <Button size="sm" variant="outline">
                    View Online
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Report Features */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>What's Included in Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">Growth Charts</h4>
                <p className="text-sm text-slate-600">
                  WHO percentile charts for weight, height, and head circumference with trend analysis
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">Speech Analysis</h4>
                <p className="text-sm text-slate-600">
                  AI-powered vocabulary assessment, clarity scores, and pronunciation evaluation
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">Motor Skills Assessment</h4>
                <p className="text-sm text-slate-600">
                  Video analysis results, balance scores, and coordination metrics
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">Milestone Tracking</h4>
                <p className="text-sm text-slate-600">
                  Comprehensive milestone checklist with achievement dates and age comparisons
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-pink-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">AI Recommendations</h4>
                <p className="text-sm text-slate-600">
                  Personalized activity suggestions and professional intervention guidance
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
              <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Share2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="text-slate-900 mb-1">Easy Sharing</h4>
                <p className="text-sm text-slate-600">
                  Professional PDF format ready to share with pediatricians and specialists
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sample Report Preview */}
      <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-slate-900 mb-1">Professional Quality Reports</h3>
              <p className="text-slate-600">
                Our reports are formatted to meet healthcare standards, making it easy for doctors and specialists to review your child's development history. All data is presented clearly with visual charts and AI-generated insights.
              </p>
            </div>
            <Button variant="outline">
              View Sample Report
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
