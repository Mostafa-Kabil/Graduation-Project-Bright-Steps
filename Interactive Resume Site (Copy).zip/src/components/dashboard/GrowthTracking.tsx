import { Plus, TrendingUp, Download, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';

const weightData = [
  { month: 0, value: 3.4, p25: 3.0, p50: 3.4, p75: 3.8 },
  { month: 3, value: 5.8, p25: 5.2, p50: 5.8, p75: 6.4 },
  { month: 6, value: 7.5, p25: 6.8, p50: 7.5, p75: 8.2 },
  { month: 9, value: 8.9, p25: 8.0, p50: 8.8, p75: 9.6 },
  { month: 12, value: 10.2, p25: 9.2, p50: 10.0, p75: 10.8 },
  { month: 15, value: 11.1, p25: 10.0, p50: 10.9, p75: 11.8 },
];

const heightData = [
  { month: 0, value: 50, p25: 48, p50: 50, p75: 52 },
  { month: 3, value: 61, p25: 59, p50: 61, p75: 63 },
  { month: 6, value: 68, p25: 66, p50: 68, p75: 70 },
  { month: 9, value: 72, p25: 70, p50: 72, p75: 74 },
  { month: 12, value: 76, p25: 74, p50: 76, p75: 78 },
  { month: 15, value: 78, p25: 76, p50: 78, p75: 80 },
];

const headCircumferenceData = [
  { month: 0, value: 35, p25: 34, p50: 35, p75: 36 },
  { month: 3, value: 40, p25: 39, p50: 40, p75: 41 },
  { month: 6, value: 43, p25: 42, p50: 43, p75: 44 },
  { month: 9, value: 45, p25: 44, p50: 45, p75: 46 },
  { month: 12, value: 46, p25: 45, p50: 46, p75: 47 },
  { month: 15, value: 47, p25: 46, p50: 47, p75: 48 },
];

const recentMeasurements = [
  { date: 'Nov 15, 2025', weight: 11.1, height: 78, head: 47, notes: 'Regular checkup' },
  { date: 'Oct 15, 2025', weight: 10.8, height: 77, head: 46.5, notes: 'Monthly tracking' },
  { date: 'Sep 15, 2025', weight: 10.5, height: 76.5, head: 46.5, notes: 'Monthly tracking' },
  { date: 'Aug 23, 2025', weight: 10.2, height: 76, head: 46, notes: '1-year checkup' },
];

export function GrowthTracking() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Growth Tracking</h1>
          <p className="text-slate-600">Monitor physical development against WHO standards</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Measurement
          </Button>
        </div>
      </div>

      {/* Current Stats */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Current Weight</div>
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">11.1 kg</div>
            <div className="flex items-center gap-2 mb-3">
              <Badge className="bg-green-200 text-green-800 border-green-300">
                55th percentile
              </Badge>
            </div>
            <div className="flex items-center gap-1 text-green-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+0.3 kg from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Current Height</div>
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">78 cm</div>
            <div className="flex items-center gap-2 mb-3">
              <Badge className="bg-blue-200 text-blue-800 border-blue-300">
                50th percentile
              </Badge>
            </div>
            <div className="flex items-center gap-1 text-blue-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+1 cm from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Head Circumference</div>
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">47 cm</div>
            <div className="flex items-center gap-2 mb-3">
              <Badge className="bg-purple-200 text-purple-800 border-purple-300">
                50th percentile
              </Badge>
            </div>
            <div className="flex items-center gap-1 text-purple-600 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+0.5 cm from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* WHO Comparison Status */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-green-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-slate-900 mb-1">Growth Status: On Track</h3>
              <p className="text-slate-600">
                Emma's growth measurements are within normal range according to WHO standards. All metrics show healthy development patterns.
              </p>
            </div>
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              Green - Healthy
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Growth Charts */}
      <Tabs defaultValue="weight" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="weight">Weight</TabsTrigger>
          <TabsTrigger value="height">Height</TabsTrigger>
          <TabsTrigger value="head">Head Circumference</TabsTrigger>
        </TabsList>

        <TabsContent value="weight">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Weight Growth Chart (WHO Standards)</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-600 rounded-full"></div>
                    <span className="text-slate-600">Emma's weight</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-slate-300 rounded-full"></div>
                    <span className="text-slate-600">WHO percentiles (25th-75th)</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={weightData}>
                  <defs>
                    <linearGradient id="percentileArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#cbd5e1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis
                    dataKey="month"
                    label={{ value: 'Age (months)', position: 'insideBottom', offset: -5 }}
                    stroke="#64748b"
                  />
                  <YAxis
                    label={{ value: 'Weight (kg)', angle: -90, position: 'insideLeft' }}
                    stroke="#64748b"
                  />
                  <Tooltip />
                  <Area type="monotone" dataKey="p75" stroke="none" fill="url(#percentileArea)" />
                  <Area type="monotone" dataKey="p25" stroke="none" fill="white" />
                  <Line
                    type="monotone"
                    dataKey="p50"
                    stroke="#cbd5e1"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#22c55e"
                    strokeWidth={3}
                    dot={{ fill: '#22c55e', r: 6 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="height">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Height Growth Chart (WHO Standards)</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-blue-600 rounded-full"></div>
                    <span className="text-slate-600">Emma's height</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-slate-300 rounded-full"></div>
                    <span className="text-slate-600">WHO percentiles (25th-75th)</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={heightData}>
                  <defs>
                    <linearGradient id="percentileAreaHeight" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#cbd5e1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis
                    dataKey="month"
                    label={{ value: 'Age (months)', position: 'insideBottom', offset: -5 }}
                    stroke="#64748b"
                  />
                  <YAxis
                    label={{ value: 'Height (cm)', angle: -90, position: 'insideLeft' }}
                    stroke="#64748b"
                  />
                  <Tooltip />
                  <Area type="monotone" dataKey="p75" stroke="none" fill="url(#percentileAreaHeight)" />
                  <Area type="monotone" dataKey="p25" stroke="none" fill="white" />
                  <Line
                    type="monotone"
                    dataKey="p50"
                    stroke="#cbd5e1"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    dot={{ fill: '#3b82f6', r: 6 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="head">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Head Circumference Growth Chart (WHO Standards)</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-purple-600 rounded-full"></div>
                    <span className="text-slate-600">Emma's head circumference</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-slate-300 rounded-full"></div>
                    <span className="text-slate-600">WHO percentiles (25th-75th)</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={headCircumferenceData}>
                  <defs>
                    <linearGradient id="percentileAreaHead" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#cbd5e1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis
                    dataKey="month"
                    label={{ value: 'Age (months)', position: 'insideBottom', offset: -5 }}
                    stroke="#64748b"
                  />
                  <YAxis
                    label={{ value: 'Head Circumference (cm)', angle: -90, position: 'insideLeft' }}
                    stroke="#64748b"
                  />
                  <Tooltip />
                  <Area type="monotone" dataKey="p75" stroke="none" fill="url(#percentileAreaHead)" />
                  <Area type="monotone" dataKey="p25" stroke="none" fill="white" />
                  <Line
                    type="monotone"
                    dataKey="p50"
                    stroke="#cbd5e1"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#9333ea"
                    strokeWidth={3}
                    dot={{ fill: '#9333ea', r: 6 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Recent Measurements */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Measurement History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentMeasurements.map((measurement, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-slate-900 mb-1">{measurement.date}</div>
                    <div className="text-sm text-slate-500">{measurement.notes}</div>
                  </div>
                </div>
                <div className="flex gap-6 text-sm">
                  <div className="text-center">
                    <div className="text-slate-500 mb-1">Weight</div>
                    <div className="text-slate-900">{measurement.weight} kg</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-500 mb-1">Height</div>
                    <div className="text-slate-900">{measurement.height} cm</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-500 mb-1">Head</div>
                    <div className="text-slate-900">{measurement.head} cm</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
