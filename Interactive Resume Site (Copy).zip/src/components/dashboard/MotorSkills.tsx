import { Video, Upload, Target, CheckCircle2, Crown, Sparkles, Play } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

const grossMotorMilestones = [
  { skill: 'Walks independently', achieved: true, ageExpected: '12-15 months', dateAchieved: 'Sep 10, 2025' },
  { skill: 'Runs with coordination', achieved: false, ageExpected: '15-18 months' },
  { skill: 'Climbs stairs with support', achieved: true, ageExpected: '12-18 months', dateAchieved: 'Oct 22, 2025' },
  { skill: 'Kicks a ball', achieved: false, ageExpected: '15-18 months' },
  { skill: 'Throws ball overhand', achieved: false, ageExpected: '18-24 months' },
];

const fineMotorMilestones = [
  { skill: 'Stacks 2-3 blocks', achieved: true, ageExpected: '12-15 months', dateAchieved: 'Aug 30, 2025' },
  { skill: 'Scribbles with crayon', achieved: true, ageExpected: '12-18 months', dateAchieved: 'Nov 5, 2025' },
  { skill: 'Turns pages in book', achieved: true, ageExpected: '12-15 months', dateAchieved: 'Sep 15, 2025' },
  { skill: 'Uses spoon independently', achieved: false, ageExpected: '15-18 months' },
  { skill: 'Builds tower of 4+ blocks', achieved: false, ageExpected: '18-24 months' },
];

const videoAnalyses = [
  {
    id: 1,
    title: 'Walking Practice',
    date: 'Nov 18, 2025',
    duration: '52 sec',
    balance: 85,
    coordination: 78,
    status: 'green',
    insights: 'Excellent balance and coordination. Walking gait is developing well.',
  },
  {
    id: 2,
    title: 'Block Stacking',
    date: 'Nov 12, 2025',
    duration: '1:15',
    balance: 80,
    coordination: 82,
    status: 'green',
    insights: 'Good hand-eye coordination. Fine motor skills are progressing nicely.',
  },
];

export function MotorSkills() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Motor Skills Assessment</h1>
          <p className="text-slate-600">AI-powered video analysis of physical development</p>
        </div>
        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0 px-4 py-2">
          <Crown className="w-4 h-4 mr-2" />
          Premium Feature
        </Badge>
      </div>

      {/* Upload Video Section */}
      <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="w-20 h-20 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Video className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-2xl text-slate-900 mb-2">Upload Activity Video</h2>
            <p className="text-slate-600 mb-6">
              Record your child performing activities like walking, stacking blocks, or playing. Our AI will analyze motor skills and coordination.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Button size="lg" className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700">
                <Video className="w-5 h-5 mr-2" />
                Record Video
              </Button>
              <Button size="lg" variant="outline">
                <Upload className="w-5 h-5 mr-2" />
                Upload Video File
              </Button>
            </div>
            <p className="text-sm text-slate-500 mt-4">
              Supported formats: MP4, MOV (30 sec - 2 min, Max 100MB)
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Current Skills Status */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Gross Motor</div>
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">85%</div>
            <div className="text-sm text-slate-600 mb-3">Walking, running, climbing</div>
            <Progress value={85} className="h-2 mb-2" />
            <div className="flex items-center gap-1 text-green-600 text-xs">
              <CheckCircle2 className="w-3 h-3" />
              <span>On track for age</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Fine Motor</div>
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">80%</div>
            <div className="text-sm text-slate-600 mb-3">Hand-eye coordination</div>
            <Progress value={80} className="h-2 mb-2" />
            <div className="flex items-center gap-1 text-blue-600 text-xs">
              <CheckCircle2 className="w-3 h-3" />
              <span>Developing well</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-600">Overall Balance</div>
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="text-4xl text-slate-900 mb-2">82%</div>
            <div className="text-sm text-slate-600 mb-3">From latest video</div>
            <Progress value={82} className="h-2 mb-2" />
            <div className="flex items-center gap-1 text-purple-600 text-xs">
              <CheckCircle2 className="w-3 h-3" />
              <span>Excellent progress</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Overall Assessment */}
      <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-green-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl text-slate-900 mb-1">Motor Skills Status: On Track</h3>
              <p className="text-slate-600">
                Emma is meeting age-appropriate motor skill milestones. Both gross and fine motor skills are developing excellently. Continue providing opportunities for physical play and exploration.
              </p>
            </div>
            <Badge className="bg-green-500 text-white text-lg px-4 py-2">
              Green - Healthy
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Milestones Tabs */}
      <Tabs defaultValue="gross" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="gross">Gross Motor Skills</TabsTrigger>
          <TabsTrigger value="fine">Fine Motor Skills</TabsTrigger>
        </TabsList>

        <TabsContent value="gross">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle>Gross Motor Milestones (Large Movements)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {grossMotorMilestones.map((milestone, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-4 p-4 rounded-xl border-2 ${
                    milestone.achieved
                      ? 'bg-green-50 border-green-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="pt-0.5">
                    {milestone.achieved ? (
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 bg-slate-300 rounded-full"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className={`mb-1 ${milestone.achieved ? 'text-slate-700' : 'text-slate-900'}`}>
                      {milestone.skill}
                    </div>
                    <div className="text-xs text-slate-500">
                      Expected: {milestone.ageExpected}
                      {milestone.dateAchieved && ` • Achieved: ${milestone.dateAchieved}`}
                    </div>
                  </div>
                  {!milestone.achieved && (
                    <Button variant="outline" size="sm">
                      Mark Complete
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fine">
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle>Fine Motor Milestones (Small Movements)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {fineMotorMilestones.map((milestone, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-4 p-4 rounded-xl border-2 ${
                    milestone.achieved
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="pt-0.5">
                    {milestone.achieved ? (
                      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4 text-white" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 bg-slate-300 rounded-full"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className={`mb-1 ${milestone.achieved ? 'text-slate-700' : 'text-slate-900'}`}>
                      {milestone.skill}
                    </div>
                    <div className="text-xs text-slate-500">
                      Expected: {milestone.ageExpected}
                      {milestone.dateAchieved && ` • Achieved: ${milestone.dateAchieved}`}
                    </div>
                  </div>
                  {!milestone.achieved && (
                    <Button variant="outline" size="sm">
                      Mark Complete
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* AI Recommendations */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-green-600" />
            Recommended Activities
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-4 p-4 bg-green-50 border border-green-200 rounded-xl">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Ball Play Practice</h4>
              <p className="text-sm text-slate-600 mb-2">
                Roll a soft ball back and forth. Practice kicking and throwing to improve coordination and gross motor skills.
              </p>
              <Badge variant="outline" className="text-xs">15-20 min daily</Badge>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Building Blocks Challenge</h4>
              <p className="text-sm text-slate-600 mb-2">
                Work on stacking taller towers. This develops hand-eye coordination and fine motor precision.
              </p>
              <Badge variant="outline" className="text-xs">10-15 min sessions</Badge>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-purple-50 border border-purple-200 rounded-xl">
            <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-slate-900 mb-1">Outdoor Exploration</h4>
              <p className="text-sm text-slate-600 mb-2">
                Let Emma walk on different surfaces (grass, sand, concrete). This improves balance and spatial awareness.
              </p>
              <Badge variant="outline" className="text-xs">Daily outdoor time</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Video Analysis History */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle>Video Analysis History</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {videoAnalyses.map((video) => (
            <div
              key={video.id}
              className="p-4 border-2 border-slate-200 rounded-xl hover:border-green-300 transition-colors"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="text-slate-900 mb-1">{video.title}</div>
                  <div className="text-sm text-slate-500">
                    {video.date} • Duration: {video.duration}
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <Play className="w-4 h-4 mr-2" />
                  Watch
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-3">
                <div>
                  <div className="text-xs text-slate-500 mb-1">Balance Score</div>
                  <div className="text-lg text-slate-900">{video.balance}%</div>
                  <Progress value={video.balance} className="h-1.5 mt-1" />
                </div>
                <div>
                  <div className="text-xs text-slate-500 mb-1">Coordination Score</div>
                  <div className="text-lg text-slate-900">{video.coordination}%</div>
                  <Progress value={video.coordination} className="h-1.5 mt-1" />
                </div>
              </div>

              <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                <div className="text-sm text-slate-700">{video.insights}</div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
