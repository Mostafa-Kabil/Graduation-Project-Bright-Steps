import { Flame, Award, Calendar, TrendingUp, Brain, Target, CheckCircle2, AlertCircle, Clock, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback } from '../ui/avatar';

export function DashboardHome() {
  return (
    <div className="p-8 space-y-6">
      {/* Header with Streak */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl text-slate-900 mb-2">Welcome back, Sarah! 👋</h1>
          <p className="text-slate-600">Here's Emma's progress today</p>
        </div>
        <div className="flex items-center gap-4">
          <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl text-slate-900">14</div>
                <div className="text-xs text-slate-600">Day Streak</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl text-slate-900">8</div>
                <div className="text-xs text-slate-600">Badges</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Child Quick Info */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <Avatar className="w-20 h-20 border-4 border-white shadow-lg">
              <AvatarFallback className="text-2xl bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                E
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl text-slate-900 mb-2">Emma Johnson</h2>
              <div className="flex items-center gap-4 text-slate-600">
                <span>15 months old</span>
                <span>•</span>
                <span>Born: Aug 23, 2024</span>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="text-center px-6 py-3 bg-white rounded-xl border border-slate-200">
                <div className="text-slate-500 text-xs mb-1">Weight</div>
                <div className="text-slate-900">11.1 kg</div>
              </div>
              <div className="text-center px-6 py-3 bg-white rounded-xl border border-slate-200">
                <div className="text-slate-500 text-xs mb-1">Height</div>
                <div className="text-slate-900">78 cm</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Development Status - Traffic Light System */}
      <div>
        <h2 className="text-xl text-slate-900 mb-4">Development Status</h2>
        <div className="grid grid-cols-3 gap-6">
          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-slate-900 mb-2">Growth Tracking</h3>
              <p className="text-slate-600 text-sm mb-3">
                Height and weight are on track with WHO standards
              </p>
              <Badge className="bg-green-200 text-green-800 border-green-300">
                On Track - Green
              </Badge>
            </CardContent>
          </Card>

          <Card className="border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center shadow-lg">
                  <AlertCircle className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-slate-900 mb-2">Speech Development</h3>
              <p className="text-slate-600 text-sm mb-3">
                Vocabulary is developing. Continue daily practice
              </p>
              <Badge className="bg-yellow-200 text-yellow-800 border-yellow-300">
                Needs Attention - Yellow
              </Badge>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
              </div>
              <h3 className="text-slate-900 mb-2">Motor Skills</h3>
              <p className="text-slate-600 text-sm mb-3">
                Excellent progress in fine and gross motor skills
              </p>
              <Badge className="bg-green-200 text-green-800 border-green-300">
                On Track - Green
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Today's Activities */}
      <div className="grid grid-cols-2 gap-6">
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Today's Recommended Activities
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-xl">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-slate-900 mb-1">Reading Time</h4>
                <p className="text-sm text-slate-600 mb-2">
                  Read a picture book together. Point to objects and say their names clearly.
                </p>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-600">15 minutes</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-purple-50 border border-purple-200 rounded-xl">
              <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-slate-900 mb-1">Stacking Blocks</h4>
                <p className="text-sm text-slate-600 mb-2">
                  Practice hand-eye coordination by stacking colorful blocks together.
                </p>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-600">10 minutes</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-green-50 border border-green-200 rounded-xl">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-slate-900 mb-1">Outdoor Walk</h4>
                <p className="text-sm text-slate-600 mb-2">
                  Take a walk outside. Encourage walking on different surfaces.
                </p>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-600">20 minutes</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Upcoming Appointments */}
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Upcoming Appointments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-4 p-4 border border-slate-200 rounded-xl">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="text-slate-900 mb-1">MMR Vaccination</div>
                  <div className="text-sm text-slate-600">Nov 28, 2025 at 10:00 AM</div>
                  <div className="text-xs text-slate-500 mt-1">Dr. Smith - City Pediatrics</div>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border border-slate-200 rounded-xl">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="text-slate-900 mb-1">15-Month Checkup</div>
                  <div className="text-sm text-slate-600">Dec 15, 2025 at 2:30 PM</div>
                  <div className="text-xs text-slate-500 mt-1">Dr. Johnson - Health Center</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Milestone Progress */}
          <Card className="border-slate-200">
            <CardHeader>
              <CardTitle>This Month's Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-700">Motor Skills</span>
                  <span className="text-slate-900">4/5</span>
                </div>
                <Progress value={80} className="h-3" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-700">Language</span>
                  <span className="text-slate-900">6/8</span>
                </div>
                <Progress value={75} className="h-3" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-700">Social Skills</span>
                  <span className="text-slate-900">5/6</span>
                </div>
                <Progress value={83} className="h-3" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card className="border-slate-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <h3 className="text-slate-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto py-4 flex-col gap-2">
              <TrendingUp className="w-6 h-6 text-blue-600" />
              <span>Log Growth</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2">
              <Brain className="w-6 h-6 text-purple-600" />
              <span>Record Speech</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2">
              <Target className="w-6 h-6 text-green-600" />
              <span>Add Activity</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2">
              <Calendar className="w-6 h-6 text-orange-600" />
              <span>Book Clinic</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}