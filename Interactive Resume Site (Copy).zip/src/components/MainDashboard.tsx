import { useState } from 'react';
import { Home, TrendingUp, Brain, Target, Sparkles, Calendar, FileText, Settings, User, Award, LogOut } from 'lucide-react';
import { DashboardHome } from './dashboard/DashboardHome';
import { ChildProfile } from './dashboard/ChildProfile';
import { GrowthTracking } from './dashboard/GrowthTracking';
import { SpeechAnalysis } from './dashboard/SpeechAnalysis';
import { MotorSkills } from './dashboard/MotorSkills';
import { Activities } from './dashboard/Activities';
import { ClinicBooking } from './dashboard/ClinicBooking';
import { Reports } from './dashboard/Reports';
import { SettingsPage } from './dashboard/SettingsPage';
import { Avatar, AvatarFallback } from './ui/avatar';
import logo from 'figma:asset/e09f16cfad98256171e82a0144b696de7a43fcbe.png';

interface MainDashboardProps {
  onLogout: () => void;
}

export function MainDashboard({ onLogout }: MainDashboardProps) {
  const [activeView, setActiveView] = useState('home');

  const navigation = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'profile', label: 'Child Profile', icon: User },
    { id: 'growth', label: 'Growth', icon: TrendingUp },
    { id: 'speech', label: 'Speech', icon: Brain },
    { id: 'motor', label: 'Motor Skills', icon: Target },
    { id: 'activities', label: 'Activities', icon: Sparkles },
    { id: 'clinic', label: 'Book Clinic', icon: Calendar },
    { id: 'reports', label: 'Reports', icon: FileText },
  ];

  const renderView = () => {
    switch (activeView) {
      case 'home':
        return <DashboardHome />;
      case 'profile':
        return <ChildProfile />;
      case 'growth':
        return <GrowthTracking />;
      case 'speech':
        return <SpeechAnalysis />;
      case 'motor':
        return <MotorSkills />;
      case 'activities':
        return <Activities />;
      case 'clinic':
        return <ClinicBooking />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardHome />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <img src={logo} alt="Bright Steps" className="h-10 mb-4" />
          <div className="flex items-center gap-3">
            <Avatar className="w-12 h-12 border-2 border-blue-200">
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                SJ
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="text-slate-900">Sarah Johnson</div>
              <div className="text-xs text-slate-500">Premium Member</div>
            </div>
            <Award className="w-5 h-5 text-yellow-500" />
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeView === item.id
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 space-y-1">
          <button
            onClick={() => setActiveView('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
              activeView === 'settings'
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-red-50 hover:text-red-600 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Log Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}
