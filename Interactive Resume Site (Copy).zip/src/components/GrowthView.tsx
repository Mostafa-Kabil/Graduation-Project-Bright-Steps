import { TrendingUp, Calendar, Plus, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';

const weightData = [
  { month: 0, value: 3.4, p25: 3.0, p50: 3.4, p75: 3.8 },
  { month: 3, value: 5.8, p25: 5.2, p50: 5.8, p75: 6.4 },
  { month: 6, value: 7.5, p25: 6.8, p50: 7.5, p75: 8.2 },
  { month: 9, value: 8.9, p25: 8.0, p50: 8.8, p75: 9.6 },
  { month: 12, value: 10.2, p25: 9.2, p50: 10.0, p75: 10.8 },
  { month: 15, value: 11.1, p25: 10.0, p50: 10.9, p75: 11.8 },
];

const heightData = [
  { month: 0, value: 50, p25: 48, p50: 50, p75: 52 },
  { month: 3, value: 61, p25: 59, p50: 61, p75: 63 },
  { month: 6, value: 68, p25: 66, p50: 68, p75: 70 },
  { month: 9, value: 72, p25: 70, p50: 72, p75: 74 },
  { month: 12, value: 76, p25: 74, p50: 76, p75: 78 },
  { month: 15, value: 78, p25: 76, p50: 78, p75: 80 },
];

const vaccinations = [
  { id: 1, name: 'Hepatitis B', date: 'Aug 23, 2024', status: 'completed' },
  { id: 2, name: 'DTaP', date: 'Oct 23, 2024', status: 'completed' },
  { id: 3, name: 'Hib', date: 'Oct 23, 2024', status: 'completed' },
  { id: 4, name: 'Polio', date: 'Oct 23, 2024', status: 'completed' },
  { id: 5, name: 'DTaP (2nd dose)', date: 'Dec 23, 2024', status: 'completed' },
  { id: 6, name: 'Rotavirus', date: 'Dec 23, 2024', status: 'completed' },
  { id: 7, name: 'DTaP (3rd dose)', date: 'Feb 23, 2025', status: 'completed' },
  { id: 8, name: 'Influenza', date: 'Jun 15, 2025', status: 'completed' },
  { id: 9, name: 'MMR', date: 'Nov 28, 2025', status: 'upcoming' },
  { id: 10, name: 'Varicella', date: 'Nov 28, 2025', status: 'upcoming' },
];

const checkups = [
  { id: 1, date: 'Aug 28, 2024', weight: 3.4, height: 50, notes: 'Newborn checkup - all normal' },
  { id: 2, date: 'Nov 23, 2024', weight: 5.8, height: 61, notes: '3-month checkup - developing well' },
  { id: 3, date: 'Feb 23, 2025', weight: 7.5, height: 68, notes: '6-month checkup - meeting milestones' },
  { id: 4, date: 'May 23, 2025', weight: 8.9, height: 72, notes: '9-month checkup - active and healthy' },
  { id: 5, date: 'Aug 23, 2025', weight: 10.2, height: 76, notes: '12-month checkup - excellent progress' },
];

export function GrowthView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-slate-900 mb-1">Growth & Health Tracking</h1>
          <p className="text-slate-500">Monitor Emma's physical development and health records</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Record
          </Button>
        </div>
      </div>

      {/* Current Stats */}
      <div className="grid grid-cols-3 gap-6">
        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-500">Current Weight</div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                55th percentile
              </Badge>
            </div>
            <div className="text-3xl text-slate-900 mb-1">11.1 kg</div>
            <div className="flex items-center gap-1 text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">+0.9 kg from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-500">Current Height</div>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                50th percentile
              </Badge>
            </div>
            <div className="text-3xl text-slate-900 mb-1">78 cm</div>
            <div className="flex items-center gap-1 text-blue-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">+2 cm from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-slate-500">BMI</div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Normal range
              </Badge>
            </div>
            <div className="text-3xl text-slate-900 mb-1">18.3</div>
            <div className="text-xs text-slate-500">Healthy weight for age</div>
          </CardContent>
        </Card>
      </div>

      {/* Growth Charts */}
      <Tabs defaultValue="weight" className="space-y-6">
        <TabsList>
          <TabsTrigger value="weight">Weight Chart</TabsTrigger>
          <TabsTrigger value="height">Height Chart</TabsTrigger>
        </TabsList>

        <TabsContent value="weight">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Weight Growth Chart</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-600 rounded"></div>
                    <span className="text-slate-600">Emma's weight</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-slate-300 rounded"></div>
                    <span className="text-slate-600">WHO percentiles</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={weightData}>
                  <defs>
                    <linearGradient id="percentileArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#cbd5e1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" label={{ value: 'Age (months)', position: 'insideBottom', offset: -5 }} stroke="#64748b" />
                  <YAxis label={{ value: 'Weight (kg)', angle: -90, position: 'insideLeft' }} stroke="#64748b" />
                  <Tooltip />
                  <Area type="monotone" dataKey="p75" stroke="none" fill="url(#percentileArea)" />
                  <Area type="monotone" dataKey="p25" stroke="none" fill="white" />
                  <Line type="monotone" dataKey="p50" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                  <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 5 }} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="height">
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Height Growth Chart</CardTitle>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-purple-600 rounded"></div>
                    <span className="text-slate-600">Emma's height</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-slate-300 rounded"></div>
                    <span className="text-slate-600">WHO percentiles</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={heightData}>
                  <defs>
                    <linearGradient id="percentileAreaHeight" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#cbd5e1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" label={{ value: 'Age (months)', position: 'insideBottom', offset: -5 }} stroke="#64748b" />
                  <YAxis label={{ value: 'Height (cm)', angle: -90, position: 'insideLeft' }} stroke="#64748b" />
                  <Tooltip />
                  <Area type="monotone" dataKey="p75" stroke="none" fill="url(#percentileAreaHeight)" />
                  <Area type="monotone" dataKey="p25" stroke="none" fill="white" />
                  <Line type="monotone" dataKey="p50" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                  <Line type="monotone" dataKey="value" stroke="#9333ea" strokeWidth={3} dot={{ fill: '#9333ea', r: 5 }} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Vaccinations and Checkups */}
      <div className="grid grid-cols-2 gap-6">
        {/* Vaccinations */}
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle>Vaccination Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {vaccinations.map((vax) => (
                <div key={vax.id} className="flex items-center justify-between p-3 border border-slate-200 rounded-lg">
                  <div className="flex-1">
                    <div className="text-slate-900 mb-1">{vax.name}</div>
                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <Calendar className="w-3 h-3" />
                      <span>{vax.date}</span>
                    </div>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      vax.status === 'completed'
                        ? 'bg-green-50 text-green-700 border-green-200'
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }
                  >
                    {vax.status === 'completed' ? 'Completed' : 'Upcoming'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Checkups */}
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle>Checkup History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {checkups.slice(0, 5).reverse().map((checkup) => (
                <div key={checkup.id} className="p-3 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-slate-900">{checkup.date}</div>
                    <div className="flex gap-3 text-xs text-slate-600">
                      <span>{checkup.weight} kg</span>
                      <span>•</span>
                      <span>{checkup.height} cm</span>
                    </div>
                  </div>
                  <div className="text-xs text-slate-500">{checkup.notes}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
