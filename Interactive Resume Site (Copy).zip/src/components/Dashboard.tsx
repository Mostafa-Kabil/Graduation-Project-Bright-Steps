import { Plus, Calendar, Activity, Target, TrendingUp, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const weightData = [
  { month: '0m', value: 3.4 },
  { month: '3m', value: 5.8 },
  { month: '6m', value: 7.5 },
  { month: '9m', value: 8.9 },
  { month: '12m', value: 10.2 },
  { month: '15m', value: 11.1 },
];

const recentActivities = [
  { id: 1, type: 'milestone', title: 'First steps taken!', time: '2 hours ago', icon: Target },
  { id: 2, type: 'health', title: 'Pediatric checkup completed', time: '3 days ago', icon: Activity },
  { id: 3, type: 'activity', title: 'Outdoor playtime - 45 minutes', time: '1 day ago', icon: Clock },
  { id: 4, type: 'milestone', title: 'Said first word "mama"', time: '5 days ago', icon: Target },
];

const upcomingAppointments = [
  { id: 1, title: 'Vaccination - MMR', date: 'Nov 28, 2025', type: 'vaccination' },
  { id: 2, title: 'Pediatric Checkup', date: 'Dec 15, 2025', type: 'checkup' },
];

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-slate-900 mb-1">Welcome back!</h1>
          <p className="text-slate-500">Here's what's happening with your child's development</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Log Activity
        </Button>
      </div>

      {/* Child Profile Card */}
      <Card className="border-slate-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <Avatar className="w-20 h-20">
              <AvatarImage src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop" />
              <AvatarFallback>EM</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-slate-900 mb-1">Emma Johnson</h2>
              <div className="flex items-center gap-4 text-slate-600">
                <span>15 months old</span>
                <span>•</span>
                <span>Born: Aug 23, 2024</span>
                <span>•</span>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Healthy
                </Badge>
              </div>
            </div>
            <div className="text-right">
              <div className="text-slate-500 mb-1">Current Weight</div>
              <div className="text-slate-900">11.1 kg</div>
            </div>
            <div className="text-right">
              <div className="text-slate-500 mb-1">Current Height</div>
              <div className="text-slate-900">78 cm</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-6">
        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <div className="text-2xl text-slate-900 mb-1">24/32</div>
            <div className="text-slate-500 mb-3">Milestones Achieved</div>
            <Progress value={75} className="h-2" />
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
            </div>
            <div className="text-2xl text-slate-900 mb-1">55th</div>
            <div className="text-slate-500 mb-3">Growth Percentile</div>
            <div className="text-xs text-green-600">Above average</div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-purple-600" />
              </div>
            </div>
            <div className="text-2xl text-slate-900 mb-1">8/10</div>
            <div className="text-slate-500 mb-3">Vaccinations</div>
            <div className="text-xs text-slate-600">Next: MMR (Nov 28)</div>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-orange-600" />
              </div>
            </div>
            <div className="text-2xl text-slate-900 mb-1">2</div>
            <div className="text-slate-500 mb-3">Upcoming Visits</div>
            <div className="text-xs text-slate-600">Next in 5 days</div>
          </CardContent>
        </Card>
      </div>

      {/* Growth Chart and Activity */}
      <div className="grid grid-cols-2 gap-6">
        {/* Weight Trend */}
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle>Weight Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={weightData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="month" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-slate-200">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const Icon = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      activity.type === 'milestone' ? 'bg-blue-100' :
                      activity.type === 'health' ? 'bg-green-100' : 'bg-purple-100'
                    }`}>
                      <Icon className={`w-4 h-4 ${
                        activity.type === 'milestone' ? 'text-blue-600' :
                        activity.type === 'health' ? 'text-green-600' : 'text-purple-600'
                      }`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-slate-900">{activity.title}</div>
                      <div className="text-xs text-slate-500">{activity.time}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Appointments */}
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Upcoming Appointments</CardTitle>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="flex items-center gap-4 p-4 border border-slate-200 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="text-slate-900 mb-1">{appointment.title}</div>
                  <div className="text-slate-500">{appointment.date}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
