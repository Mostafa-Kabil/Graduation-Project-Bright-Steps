import { CheckCircle2, Circle, Camera, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

const milestones = {
  motor: {
    title: 'Motor Skills',
    color: 'blue',
    progress: 80,
    items: [
      { id: 1, title: 'Holds head up', achieved: true, date: 'Oct 15, 2024', ageRange: '2-4 months' },
      { id: 2, title: 'Rolls over', achieved: true, date: 'Nov 28, 2024', ageRange: '4-6 months' },
      { id: 3, title: 'Sits without support', achieved: true, date: 'Jan 10, 2025', ageRange: '6-8 months' },
      { id: 4, title: 'Crawls', achieved: true, date: 'Mar 5, 2025', ageRange: '7-10 months' },
      { id: 5, title: 'Pulls to stand', achieved: true, date: 'May 20, 2025', ageRange: '9-12 months' },
      { id: 6, title: 'Takes first steps', achieved: true, date: 'Sep 10, 2025', ageRange: '12-15 months' },
      { id: 7, title: 'Walks independently', achieved: false, ageRange: '12-18 months' },
      { id: 8, title: 'Runs', achieved: false, ageRange: '15-18 months' },
    ],
  },
  language: {
    title: 'Language & Communication',
    color: 'green',
    progress: 70,
    items: [
      { id: 1, title: 'Coos and babbles', achieved: true, date: 'Nov 5, 2024', ageRange: '2-4 months' },
      { id: 2, title: 'Responds to name', achieved: true, date: 'Jan 15, 2025', ageRange: '6-9 months' },
      { id: 3, title: 'Says "mama" or "dada"', achieved: true, date: 'Apr 22, 2025', ageRange: '8-12 months' },
      { id: 4, title: 'Uses simple gestures', achieved: true, date: 'Jun 8, 2025', ageRange: '9-12 months' },
      { id: 5, title: 'Says first word', achieved: true, date: 'Aug 30, 2025', ageRange: '12-15 months' },
      { id: 6, title: 'Follows simple commands', achieved: false, ageRange: '12-18 months' },
      { id: 7, title: 'Says 3-5 words', achieved: false, ageRange: '15-18 months' },
    ],
  },
  social: {
    title: 'Social & Emotional',
    color: 'purple',
    progress: 75,
    items: [
      { id: 1, title: 'Smiles at people', achieved: true, date: 'Oct 20, 2024', ageRange: '2-3 months' },
      { id: 2, title: 'Plays peek-a-boo', achieved: true, date: 'Feb 5, 2025', ageRange: '6-9 months' },
      { id: 3, title: 'Shows fear of strangers', achieved: true, date: 'Mar 18, 2025', ageRange: '7-10 months' },
      { id: 4, title: 'Shows affection', achieved: true, date: 'Jul 12, 2025', ageRange: '9-12 months' },
      { id: 5, title: 'Plays simple games', achieved: true, date: 'Sep 25, 2025', ageRange: '12-15 months' },
      { id: 6, title: 'Shows independence', achieved: false, ageRange: '15-18 months' },
    ],
  },
  cognitive: {
    title: 'Cognitive Development',
    color: 'orange',
    progress: 65,
    items: [
      { id: 1, title: 'Tracks objects with eyes', achieved: true, date: 'Oct 12, 2024', ageRange: '2-4 months' },
      { id: 2, title: 'Explores with hands and mouth', achieved: true, date: 'Dec 20, 2024', ageRange: '4-6 months' },
      { id: 3, title: 'Finds hidden objects', achieved: true, date: 'Apr 8, 2025', ageRange: '8-10 months' },
      { id: 4, title: 'Uses objects correctly', achieved: true, date: 'Aug 15, 2025', ageRange: '12-15 months' },
      { id: 5, title: 'Points to objects', achieved: false, ageRange: '12-18 months' },
      { id: 6, title: 'Follows 2-step commands', achieved: false, ageRange: '15-18 months' },
    ],
  },
};

export function MilestonesView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-slate-900 mb-1">Developmental Milestones</h1>
          <p className="text-slate-500">Track Emma's growth and achievements</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Camera className="w-4 h-4 mr-2" />
          Add Milestone
        </Button>
      </div>

      {/* Overall Progress */}
      <Card className="border-slate-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-slate-900 mb-1">Overall Progress</h3>
              <p className="text-slate-500">Emma is meeting age-appropriate milestones</p>
            </div>
            <Badge className="bg-green-100 text-green-700 border-green-200">On Track</Badge>
          </div>
          <div className="grid grid-cols-4 gap-6">
            {Object.values(milestones).map((category) => (
              <div key={category.title}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-700">{category.title}</span>
                  <span className="text-slate-900">{category.progress}%</span>
                </div>
                <Progress value={category.progress} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Milestone Categories */}
      <Tabs defaultValue="motor" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="motor">Motor Skills</TabsTrigger>
          <TabsTrigger value="language">Language</TabsTrigger>
          <TabsTrigger value="social">Social & Emotional</TabsTrigger>
          <TabsTrigger value="cognitive">Cognitive</TabsTrigger>
        </TabsList>

        {Object.entries(milestones).map(([key, category]) => (
          <TabsContent key={key} value={key}>
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle>{category.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.items.map((milestone) => (
                    <div
                      key={milestone.id}
                      className={`flex items-start gap-4 p-4 rounded-lg border ${
                        milestone.achieved
                          ? 'border-slate-200 bg-slate-50'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="pt-0.5">
                        {milestone.achieved ? (
                          <CheckCircle2 className={`w-5 h-5 text-${category.color}-600`} />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-300" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className={`mb-1 ${milestone.achieved ? 'text-slate-700' : 'text-slate-900'}`}>
                          {milestone.title}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500">
                          <span>Expected: {milestone.ageRange}</span>
                          {milestone.achieved && (
                            <>
                              <span>•</span>
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                <span>Achieved: {milestone.date}</span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                      {!milestone.achieved && (
                        <Button variant="outline" size="sm">
                          Mark Complete
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
