# Bright Steps - HTML/CSS/JavaScript Version

AI-powered child development monitoring system for ages 0-5 years.

## Project Structure

```
/project
├── /pages
│   ├── index.html          # Landing page
│   ├── login.html          # Login page
│   ├── signup.html         # Signup page
│   └── dashboard.html      # Dashboard (protected)
├── /styles
│   ├── globals.css         # Global styles and variables
│   ├── landing.css         # Landing page styles
│   ├── auth.css            # Login/signup styles
│   └── dashboard.css       # Dashboard styles
├── /scripts
│   ├── navigation.js       # Navigation utilities
│   ├── landing.js          # Landing page logic
│   ├── auth.js             # Authentication logic
│   └── dashboard.js        # Dashboard logic
└── README.md
```

## Features

### Pages
1. **Landing Page** (`index.html`)
   - Hero section with animated card preview
   - Features grid (6 features)
   - Traffic-light system explanation
   - Pricing section (Free & Premium)
   - CTA section
   - Footer with links

2. **Login Page** (`login.html`)
   - Email and password fields
   - Social login buttons (Google, Facebook)
   - Link to signup page
   - Back to landing button

3. **Signup Page** (`signup.html`)
   - Full name, email, password fields
   - Terms & conditions checkbox
   - Social signup buttons
   - Link to login page
   - Back to landing button

4. **Dashboard** (`dashboard.html`)
   - Sidebar navigation with 8 views
   - User profile header
   - Multiple dashboard views:
     - Home (default)
     - Child Profile
     - Growth Tracking
     - Speech Analysis (Premium)
     - Motor Skills (Premium)
     - Activities
     - Clinic Booking (Premium)
     - Reports (Premium)
     - Settings

### Design System

#### Colors
- **Primary**: Blue (#2563eb) to Purple (#9333ea) gradients
- **Success**: Green (#22c55e)
- **Warning**: Yellow (#eab308)
- **Danger**: Red (#ef4444)
- **Neutral**: Slate (#475569)

#### Typography
- Font Family: System fonts (-apple-system, BlinkMacSystemFont, Segoe UI, Roboto)
- Headings: 800 weight, -2% letter spacing
- Body: 400 weight, 1.6 line height

#### Components
- Buttons: Multiple variants (gradient, outline, ghost, white)
- Badges: Color-coded for features and status
- Cards: Rounded corners (0.75rem - 1.875rem)
- Icons: SVG-based, inline

## Authentication

### Mock Authentication
The app uses `sessionStorage` for client-side authentication simulation:
- Login/signup sets `isAuthenticated` to `true`
- Dashboard is protected and redirects to login if not authenticated
- Logout clears session storage

### User Data Structure
```javascript
{
    email: "user@example.com",
    name: "Sarah Johnson",
    isPremium: true/false
}
```

## Navigation

### Client-Side Routing
- Uses `navigateTo(page)` function
- Pages: 'index', 'login', 'signup', 'dashboard'
- Protected routes check authentication before rendering

### Dashboard Views
- Views are loaded dynamically via JavaScript
- Template-based rendering for home view
- Inline HTML generation for other views
- Active navigation highlighting

## Responsive Design

### Breakpoints
- Desktop: > 1024px
- Tablet: 768px - 1024px
- Mobile: < 768px

### Responsive Features
- Stacked layouts on mobile
- Horizontal scroll for dashboard navigation
- Flexible grid columns (3 → 2 → 1)
- Adjusted font sizes
- Touch-friendly button sizes

## Browser Support
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Getting Started

1. Open `pages/index.html` in a web browser
2. Navigate through the landing page
3. Click "Get Started Free" or "Log In"
4. Enter any email/password (mock auth)
5. Explore the dashboard

## Development Notes

### No Build Process
- Pure HTML, CSS, and JavaScript
- No npm dependencies
- No bundlers or transpilers
- Can be served from any static file server

### Inline SVG Icons
- Lucide React icons converted to inline SVG
- Maintains original stroke-based design
- Customizable via CSS

### Animations
- CSS transitions for hover states
- Intersection Observer for scroll animations
- Transform-based effects

### Code Organization
- Separate CSS files for each page type
- Modular JavaScript with IIFE pattern
- Shared navigation utilities
- Template-based view rendering

## Future Enhancements

### Potential Additions
- Real backend integration
- Form validation library
- Chart.js for growth tracking visualizations
- Image upload functionality
- Calendar component for appointments
- PDF generation for reports
- Progressive Web App (PWA) features
- Offline support

## License
Educational/demonstration purposes

## Credits
Bright Steps - Child Development Monitoring System
