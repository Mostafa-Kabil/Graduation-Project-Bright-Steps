
  # Interactive Resume Site (Copy)

  This is a code bundle for Interactive Resume Site (Copy). The original project is available at https://www.figma.com/design/fZ2qDu3PFUE52UWMnZfbr7/Interactive-Resume-Site--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  